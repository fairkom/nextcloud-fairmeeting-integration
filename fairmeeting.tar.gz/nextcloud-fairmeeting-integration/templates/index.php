<?php

declare(strict_types=1);

use OCA\fairmeeting\AppInfo\Application;

script(Application::APP_ID, 'index');

?>

<div id="fairmeeting"></div>
