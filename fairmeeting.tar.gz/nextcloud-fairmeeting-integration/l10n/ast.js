OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Cargando…",
		"Saving …": "Guardando…",
		"Failed to save settings": "Nun se pue guardar la configuración",
		"Failed to load settings": "Nun se pue cargar la configuración",
		"Browser not supported": "El restolador nun ye compatible",
		"Link copied": "Copióse l'enllaz",
		"Cannot copy, please copy the link manually":
			"Nun se pue copiar. Copia l'enllaz manualmente",
		"Copy to clipboard": "Copiar nel cartafueyu",
		Help: "Ayuda",
		Camera: "Cámara",
		Join: "Xunise",
		"Room not found": "Nun s'atopó la sala",
		"Audio output": "Salida d'audiu",
	},
	"nplurals=2; plural=(n != 1);"
);
