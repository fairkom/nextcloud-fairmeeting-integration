OC.L10N.register(
	"fairmeeting",
	{
		"Saving …": "Menyimpan ...",
		"Failed to save settings": "Gagal simpan setelan",
		"Browser not supported": "Peramban tidak didukung",
		"Link copied": "Link tersalin",
		"Copy to clipboard": "Salin ke papan klip",
		Help: "Bantuan",
		Camera: "Kamera",
		Join: "Gabung",
		"Room not found": "Ruang tidak ditemukan",
	},
	"nplurals=1; plural=0;"
);
