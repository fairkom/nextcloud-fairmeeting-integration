OC.L10N.register(
	"fairmeeting",
	{
		save: "salvesta",
		"Saving …": "Salvestamine …",
		Conference: "Konverents",
		"Browser not supported": "Brauser pole toetatud",
		"Link copied": "Link kopeeritud",
		"Cannot copy, please copy the link manually":
			"Ei saa kopeerida, palun kopeeri link käsitsi",
		"Copy to clipboard": "Kopeeri lõikepuhvrisse",
		Help: "Abiinfo",
	},
	"nplurals=2; plural=(n != 1);"
);
