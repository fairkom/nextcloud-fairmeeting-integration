OC.L10N.register(
	"fairmeeting",
	{
		save: "guardar",
		"Link copied": "Link copiado",
		"Cannot copy, please copy the link manually":
			"No es posible copiar, por favor copia el enlace manualmente",
		"Copy to clipboard": "Copiar al portapapeles",
		Help: "Ayuda",
		Camera: "Cámara",
	},
	"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;"
);
