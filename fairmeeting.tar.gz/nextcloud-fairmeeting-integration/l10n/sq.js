OC.L10N.register(
	"fairmeeting",
	{
		"Link copied": "Linku u kopjua",
		"Copy to clipboard": "Kopjo në dërrasë ",
		Browser: "Shfletues",
		Help: "Ndihmë",
		Camera: "Kamera",
	},
	"nplurals=2; plural=(n != 1);"
);
