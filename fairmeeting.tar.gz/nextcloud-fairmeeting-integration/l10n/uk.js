OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Завантаження...",
		save: "зберегти",
		"Saving …": "Збереження …",
		"Failed to save settings": "Неможливо зберегти налаштування",
		"Failed to load settings": "Не вдалося завантажити налаштування",
		Conference: "Конференція",
		"Browser not supported": "Оглядач не підтримується",
		"Download the desktop app here ↗": "Отримати настільний застосунок ↗",
		"Link copied": "Посилання скопійовано",
		"Cannot copy, please copy the link manually":
			"Неможливо скопіювати, скопіюйте посилання вручну",
		"Copy to clipboard": "Копіювати до буферу обміну",
		Browser: "Переглядач",
		Help: "Допомога",
		Camera: "Камера",
		Join: "Приєднатися",
		"Audio output": "Вивід аудіо",
	},
	"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);"
);
