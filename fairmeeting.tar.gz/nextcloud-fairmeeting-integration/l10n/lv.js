OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Ielādē…",
		"Saving …": "Saglabā ...",
		"Failed to save settings": "Neizdevās saglabāt iestatījumus",
		Conference: "Konference",
		"Browser not supported": "Pārlūkprogramma netiek atbalstīta",
		"Link copied": "Saite nokopēta",
		"Copy to clipboard": "Kopēt starpliktuvē",
		Browser: "Pārlūks",
		Help: "Palīdzība",
		Join: "Pievienoties",
	},
	"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);"
);
