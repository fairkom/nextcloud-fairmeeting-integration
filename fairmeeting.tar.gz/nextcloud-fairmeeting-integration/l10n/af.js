OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Laai …",
		"Saving …": "Bewaar tans…",
		"Link copied": "Skakel gekopieer",
		Help: "Hulp",
		Camera: "Kamera",
		Microphone: "Mikrofoon",
		Join: "Sluit aan",
	},
	"nplurals=2; plural=(n != 1);"
);
