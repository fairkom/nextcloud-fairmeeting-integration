OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Loading …",
		"Saving …": "Saving …",
		"Failed to save settings": "Failed to save settings",
		Conference: "Conference",
		"Browser not supported": "Browser not supported",
		"Link copied": "Link copied",
		"Cannot copy, please copy the link manually":
			"Cannot copy, please copy the link manually",
		"Copy to clipboard": "Copy to clipboard",
		Help: "Help",
		Camera: "Camera",
		Join: "Join",
	},
	"nplurals=2; plural=(n!=1);"
);
