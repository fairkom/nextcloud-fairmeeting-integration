OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Loading …",
		save: "Gem",
		"Saving …": "Gemmer ...",
		"Failed to save settings": "Kunne ikke gemme indstillinger",
		"Failed to load settings": "Fejl ved indlæsning af indstillinger",
		Conference: "Konference",
		"Browser not supported": "Browser ikke understøttet",
		"Link copied": "Link kopieret",
		"Cannot copy, please copy the link manually":
			"Kan ikke kopiere, kopier venligst linket manuelt",
		"Copy to clipboard": "Kopier til udklipsholder",
		Browser: "Browser",
		Help: "Hjælp",
		Camera: "Kamera",
		Join: "Deltag",
		"Delete room": "Slet rum",
	},
	"nplurals=2; plural=(n != 1);"
);
