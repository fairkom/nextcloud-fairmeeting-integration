OC.L10N.register(
	"fairmeeting",
	{
		"Saving …": "กำลังบันทึก …",
		"Failed to save settings": "ไม่สามารถบันทึกการตั้งค่าได้",
		"Failed to load settings": "ไม่สามารถโหลดการตั้งค่าได้",
		"Browser not supported": "ไม่รองรับเบราว์เซอร์",
		"Link copied": "คัดลอกลิงก์แล้ว",
		"Cannot copy, please copy the link manually":
			"ไม่สามารถคัดลอก กรุณาคัดลอกลิงก์เอง",
		"Copy to clipboard": "คัดลอกไปยังคลิปบอร์ด",
		Help: "ช่วยเหลือ",
		Camera: "กล้อง",
		"Room not found": "ไม่พบห้อง",
	},
	"nplurals=1; plural=0;"
);
