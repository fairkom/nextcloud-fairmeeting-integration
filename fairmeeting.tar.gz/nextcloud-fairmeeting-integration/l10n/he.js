OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "בטעינה…",
		save: "שמירה",
		"Saving …": "מתבצעת שמירה…",
		"Failed to save settings": "שמירת ההגדרות נכשלה",
		"Failed to load settings": "טעינת ההגדרות נכשלה",
		Conference: "כנס",
		"Link copied": "הקישור הועתק",
		"Cannot copy, please copy the link manually":
			"לא ניתן להעתיק, נא להעתיק את הקישור ידנית",
		"Copy to clipboard": "העתקה ללוח הגזירים",
		Browser: "דפדפן",
		Help: "עזרה",
		Camera: "מצלמה",
		Microphone: "מיקרופון",
		Join: "הצטרף",
	},
	"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;"
);
