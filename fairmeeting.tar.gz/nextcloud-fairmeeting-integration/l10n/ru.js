OC.L10N.register(
	"fairmeeting",
	{
		conferences: "конференции",
		"fairmeeting Integration": "интеграция с fairmeeting",
		Conferences: "Конференции",
		"fairmeeting Integration (unofficial)":
			"Интеграция с fairmeeting (неофициальная)",
		"This app integrates fairmeeting conferences into Nextcloud.\n\nFeatures:\n- 🎥 Easy online conferences in Nextcloud utilising fairmeeting\n- 🔗 Sharable conference room links\n- 🔎 Shows conference rooms in the global search\n- ✅ System test before joining a conference\n\nPlease read the [documentation](https://github.com/nextcloud/fairmeeting).":
			"Это приложение интегрирует конференции fairmeeting в Nextcloud.\n\nФункции:\n- 🎥 Простые онлайн-конференции в Nextcloud с использованием fairmeeting\n- 🔗 Общие ссылки на конференц-залы\n- 🔎 Показывает конференц-залы в глобальном поиске\n- ✅ Проверка системы перед подключением к конференции\n\nПожалуйста, прочтите [документацию] (https://github.com/nextcloud/fairmeeting)",
		"Loading …": "Загрузка ...",
		"Server URL (required)": "URL-адрес сервера (обязательно)",
		"Help link (optional)": "Ссылка на помощь (необязательно)",
		'Display "Join using the fairmeeting app"':
			"Показать «Присоединиться с помощью приложения fairmeeting»",
		"JWT Secret (optional)": "Секрет JWT (необязательно)",
		"JWT App ID": "JWT Идентификатор приложения",
		save: "сохранить",
		saved: "сохранено",
		"Saving …": "Сохранение…",
		"Please provide a fairmeeting instance URL":
			"Укажите URL-адрес экземпляра fairmeeting.",
		"The server URL must start with https://":
			"URL-адрес сервера должен начинаться с https://",
		"It is highly recommended to set up a dedicated fairmeeting instance":
			"Настоятельно рекомендуется настроить выделенный экземпляр fairmeeting.",
		"Please provide the App ID": "Укажите идентификатор приложения.",
		"Failed to save settings": "Не удалось сохранить настройки",
		"Failed to load settings": "Не удалось загрузить настройки",
		"Conference rooms": "Конференц-залы",
		Conference: "Конференция",
		"Conference left": "Покинуть конференцию",
		"Problems detected": "Обнаружены проблемы",
		"Your browser is non-optimal:": "Ваш браузер неоптимален:",
		"Audio and video quality could be poor. It is recommended to use a recent <b>Firefox/Chrome/Chromium</b> version.":
			"Качество звука и видео может быть низким. Рекомендуется использовать последнюю версию <b>Firefox/Chrome/Chromium</b>.",
		"Browser not supported": "Используемый браузер не поддерживается",
		"Show system check": "Показать проверку системы",
		"Your name:": "Ваше имя:",
		"Click here to join": "Нажмите здесь, чтобы присоединиться",
		"Start muted": "Начать без звука",
		"Start with camera off": "Начать с выключенной камерой",
		"Join with desktop app": "Присоединиться при помощи настольного приложения",
		"Join with mobile app": "Присоединиться при помощи мобильного приложения",
		"App button not working?": "Кнопка приложения не работает?",
		"Download the desktop app here ↗":
			"Загрузите настольное приложение здесь ↗",
		"The mobile app is available via the app store of your choice.":
			"Мобильное приложение доступно в магазине приложений по вашему выбору.",
		"After successful installation try the button again.":
			"После успешной установки попробуйте нажать кнопку еще раз.",
		"Still not working? Copy the link below and paste it into the input field on the fairmeeting App start screen.":
			"Все еще не работает? Скопируйте ссылку ниже и вставьте ее в поле ввода на стартовом экране приложения fairmeeting.",
		"Link copied": "Ссылка скопирована",
		"Cannot copy, please copy the link manually":
			"Не удалось скопировать, выполните копирование вручную",
		"Copy to clipboard": "Копировать в буфер",
		Browser: "Браузер",
		"not supported": "Не поддерживается",
		"Audio and video quality could be poor.<br> It is recommended to use a recent <b>Firefox/Chrome/Chromium</b> version.":
			"Качество звука и видео может быть низким.<br> Рекомендуется использовать последнюю версию <b>Firefox/Chrome/Chromium</b>.",
		Help: "Помощь",
		Camera: "Камера",
		"Name of the new room": "Название новой комнаты",
		"No conference rooms yet": "Комнат для конференций пока нет",
		"Create the first room:": "Создать комнату обсуждения",
		Microphone: "Микрофон",
		Join: "Присоединиться",
		"Delete room": "Удалить комнату",
		"Room not found": "Комната не найдена",
		"Please check the link/URL and ask your host":
			"Пожалуйста, проверьте ссылку/URL и спросите своего хоста",
		"Audio output": "Аудиовыход",
		"Play test sound": "Воспроизвести тестовый звук",
		"System check": "Проверка системы",
		"• Accept the microphone/camera access permissions at the top of the screen":
			"• Примите разрешения на доступ к микрофону/камере в верхней части экрана.",
		"• Check the microphone/camera access permissions by clicking the icon next to the address bar. Then reload the page.":
			"• Проверьте разрешения на доступ к микрофону/камере, щелкнув значок рядом с адресной строкой. Затем перезагрузите страницу.",
		"• If you have DroidCam: Connect to the mobile camera, then reload the page":
			"• Если у вас есть DroidCam: подключитесь к мобильной камере, затем перезагрузите страницу.",
		"• Try join using the fairmeeting app (follow the instructions at the bottom of the page)":
			"• Попробуйте присоединиться с помощью приложения fairmeeting (следуйте инструкциям внизу страницы).",
		"No camera/microphone access": "Нет доступа к камере/микрофону",
		"Review your browser camera and microphone access settings":
			"Проверьте настройки доступа к камере и микрофону в браузере.",
		"Click here for {browser} instructions":
			"Щелкните здесь, чтобы получить инструкции для {браузера}",
		"Does not work?": "Не работает?",
		"Click here for troubleshooting help":
			"Щелкните здесь, чтобы получить помощь по устранению неполадок",
		"Conferences app not yet configured":
			"Приложение для конференций еще не настроено",
		"Please contact your administrator to set up the conferences app.":
			"Обратитесь к администратору, чтобы настроить приложение для конференций.",
		"It is recommended to use the latest version of one of the following browsers:":
			"Рекомендуется использовать последнюю версию одного из следующих браузеров:",
	},
	"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);"
);
