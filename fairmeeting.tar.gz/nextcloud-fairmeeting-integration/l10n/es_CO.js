OC.L10N.register(
	"fairmeeting",
	{
		save: "guardar",
		"Link copied": "Enlace copiado",
		"Copy to clipboard": "Copiar al portapapeles",
		Browser: "Navegador",
		Help: "Ayuda",
		"Delete room": "Eliminar cuarto",
	},
	"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;"
);
