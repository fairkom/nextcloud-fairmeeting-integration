OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Carrigamentu...",
		"Saving …": "Sarvende …",
		"Failed to save settings": "No at fatu a sarvare is informatziones",
		"Failed to load settings": "Impossìbile carrigare sa cunfiguratzione",
		Conference: "Cunferèntzia",
		"Browser not supported": "Navigadore non suportadu",
		"Link copied": "Ligòngiu copiadu",
		"Cannot copy, please copy the link manually":
			"No at fatu a copiare, copia su ligòngiu a manu",
		"Copy to clipboard": "Còpia in is punta de billete",
		Browser: "Navigadore",
		Help: "Agiudu",
		Camera: "Fotocàmera",
		Microphone: "Micròfonu",
		Join: "Intra",
		"Room not found": "Istantza no agatada",
	},
	"nplurals=2; plural=(n != 1);"
);
