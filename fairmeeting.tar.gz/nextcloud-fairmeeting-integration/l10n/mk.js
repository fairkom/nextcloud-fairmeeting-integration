OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Се вчитува…",
		"Saving …": "Зачувува ...",
		"Failed to save settings": "Неуспешно зачувување на параметрите",
		"Failed to load settings": "Неуспешно вчитување на параметрите",
		Conference: "Конференција",
		"Browser not supported": "Вашиот прелистувач не е поддржан",
		"Link copied": "Линкот е копиран",
		"Cannot copy, please copy the link manually":
			"Неможе да се копира, копирајте го линкот рачно",
		"Copy to clipboard": "Копирај во клипборд",
		Help: "Помош",
		Camera: "Камера",
		Microphone: "Микрофон",
		Join: "Приклучи се",
	},
	"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;"
);
