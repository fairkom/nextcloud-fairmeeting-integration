OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Ladataan…",
		save: "tallenna",
		saved: "tallennettu",
		"Saving …": "Tallennetaan…",
		"Failed to save settings": "Asetusten tallentaminen epäonnistui",
		"Failed to load settings": "Asetusten lataaminen epäonnistui",
		Conference: "Konfrenssi",
		"Browser not supported": "Selain ei ole tuettu",
		"Link copied": "Linkki kopioitu",
		"Cannot copy, please copy the link manually":
			"Kopioiminen ei onnistu. Kopioi linkki manuaalisesti",
		"Copy to clipboard": "Kopioi leikepöydälle",
		Browser: "Selain",
		Help: "Ohje",
		Camera: "Kamera",
		Microphone: "Mikrofoni",
		Join: "Liity",
		"Delete room": "Poista huone",
		"Room not found": "Huonetta ei löytynyt",
		"Audio output": "Äänen ulostulo",
	},
	"nplurals=2; plural=(n != 1);"
);
