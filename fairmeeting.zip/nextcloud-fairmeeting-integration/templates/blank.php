<style>
    #header {
        display: none !important;
    }
</style>
