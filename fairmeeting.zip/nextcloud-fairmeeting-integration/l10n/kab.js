OC.L10N.register(
	"fairmeeting",
	{
		Conferences: "Isaragen",
		"Loading …": "Asali ...",
		Conference: "Asarag",
		"Link copied": "Aseɣwen yettwanɣel",
		"Copy to clipboard": "Copier dans le presse-papiers",
		Browser: "Iminig",
		Help: "Tallalt",
		Camera: "Takamiṛat",
		Microphone: "Asawaḍ",
		Join: "Semlil",
		"Room not found": "Ur tettwaf ara texxamt",
		"Audio output": "Anekcum n umeslaw",
	},
	"nplurals=2; plural=(n != 1);"
);
