OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Yn llwytho …",
		Conference: "Cynhadledd",
		"Link copied": "Dolen wedi'i gopïo",
		Help: "Cymorth",
	},
	"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;"
);
