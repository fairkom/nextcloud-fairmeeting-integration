OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Se încarcă…",
		"Saving …": "Se salvează",
		Conference: "Conferință",
		"Browser not supported": "Browser incompatibil",
		"Link copied": "Link copiat",
		"Cannot copy, please copy the link manually":
			"Nu s-a putut copia, vă rugăm să copiați link-ul manual",
		"Copy to clipboard": "Copiază în clipboard",
		Browser: "Browser",
		Help: "Ajutor",
		Camera: "Camera",
	},
	"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));"
);
