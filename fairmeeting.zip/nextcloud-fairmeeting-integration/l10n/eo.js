OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "Ŝargas …",
		save: "konservi",
		saved: "konservita",
		"Saving …": "Konservado...",
		"Failed to save settings": "Konservo de agordoj malsukcesis",
		"Failed to load settings": "Ŝargo de agordoj malsukcesis",
		"Link copied": "Ligilo kopiita",
		"Cannot copy, please copy the link manually":
			"Ne eblis kopii la ligilon; kopiu ĝin permane.",
		"Copy to clipboard": "Kopii tondejen",
		Help: "Helpo",
		Camera: "Fotilo",
		Join: "Aliĝi",
	},
	"nplurals=2; plural=(n != 1);"
);
