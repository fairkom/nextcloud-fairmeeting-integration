OC.L10N.register(
	"fairmeeting",
	{
		conferences: "conferéncias",
		"fairmeeting Integration": "integracion fairmeeting",
		Conferences: "Conferéncias",
		"Loading …": "Cargament…",
		saved: "enregistrat",
		"Saving …": "Enregistrament...",
		Conference: "Conferéncia",
		"Browser not supported": "Navegador pas pres en carga",
		"Link copied": "Ligam copiat",
		"Copy to clipboard": "Copiar dins lo quichapapièrs",
		Help: "Ajuda",
		Camera: "Camèra",
		Microphone: "Microfòn",
		Join: "Rejónher",
	},
	"nplurals=2; plural=(n > 1);"
);
