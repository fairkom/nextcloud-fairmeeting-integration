OC.L10N.register(
	"fairmeeting",
	{
		"Copy to clipboard": "კოპირება ბუფერში",
		Browser: "ბრაუზერი",
		Help: "დახმარება",
		"Delete room": "ოთახის გაუქმება",
	},
	"nplurals=2; plural=(n!=1);"
);
