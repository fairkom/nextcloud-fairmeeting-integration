OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "ກຳລັງໂຫຼດ",
		"Saving …": "ກຳລັງບັນທຶກ",
		"Link copied": "ສຳເນົາລິງ",
		Help: "ການຊ່ວຍເຫຼືອ",
		Camera: "ກ້ອງຖ່າຍຮຸບ",
	},
	"nplurals=1; plural=0;"
);
