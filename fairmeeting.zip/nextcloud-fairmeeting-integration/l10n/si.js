OC.L10N.register(
	"fairmeeting",
	{
		"Loading …": "පූරණය වෙමින් …",
		"Link copied": "සබැඳිය පිටපත් කළා",
		Help: "උපකාර",
		Join: "එක්වන්න",
	},
	"nplurals=2; plural=(n != 1);"
);
